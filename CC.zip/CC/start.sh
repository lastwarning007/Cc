toilet -f pagga S t a r t e d |lolcat
python3 bot.py
